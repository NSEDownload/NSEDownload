# from stocks import *

# df1 = get_data("RELIANCE", full_data = True)
# df2 = get_data("RELIANCE", start_date = '1-1-2015', end_date = '1-1-2022')

# print(df1, df2)

